DBeaver 7.1.3 for AppStore

This is a special DBeaver distribution for Microsoft and Apple app store.

License
==========================
  Apache License 2 (http://www.apache.org/licenses/LICENSE-2.0)

Contacts
==========
  Main web site: https://dbeaver.io
  Source code: https://github.com/dbeaver/dbeaver
  Technical support, sales: dbeaver@jkiss.org
